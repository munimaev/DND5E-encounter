var UI_Party_Hero = function(o) {
	// if (!o.hasOwnProperty('div')) {
	// 	throw new Error('Нет свойства div');
	// } else {
	// 	if (typeof o.div == 'string') {
	// 		this.$parrent = $(o.div)
	// 	} else {
	// 		this.$parrent = o.div;
	// 	}
	// }
	if (!o.hasOwnProperty('module')) {
		throw new Error('Нет свойства module');
	} else {
		this.module = o.module;
	}
	this.id = o.data.id;
	this.data = o.data;
	this.displayed = false;
	this.$stats = o.statdiv;
	this.init();
	this.createHTML();
}

UI_Party_Hero.prototype.init = function() {
	this.name = this.data.name;
	this.type = this.data.type;
	this.race = this.data.race;
	this.class = this.data.class;
	this.level = this.data.level;
	this.initiative = this.data.initiative;
	this.speed = this.data.speed;
	this.ac = this.data.ac;

	this.aligment = this.data.aligment;
	this.skills = [];
	this.skillsIndex = {};
	this.bindEvents();
};

UI_Party_Hero.prototype.createHTML = function() {
	this.createHTMLInList();
	this.createHTMLStats();
}

UI_Party_Hero.prototype.createHTMLInList = function() {
	this.$divInList = $('<div />', {class:'batle-encounter withHoverButtons'});
	var funcSelcet = function(self) {
		return function() {
			self.module.callEvent('selectHero',self.id);
		}
	}(this)

	this.$divInList.append((this.$l_header = $('<div />', {
		class: 'batle-encounter-name link',
		text: this.name,
		click: funcSelcet
	})));
	this.$divInList.append((this.$l_subheader = $('<div />', {
		class: 'party-hero-type',
		text: this.race + ', ' + this.class + ', ' + app.local('Level') + ' ' + this.level,
		click: funcSelcet 
	})));
}

UI_Party_Hero.prototype.createHTMLStats = function() {
	this.$divStats = $('<div />', {class:'party-hero-stats'});
	var base = $('<div />', {class:'party-hero-base'});
	var name = $('<div />', {class:'party-hero-name'});
	var nameTitle = $('<div />', {class:'party-hero-title', text: app.local('Name')});
	var nameValue = $('<div />', {class:'party-hero-value-large', text: this.name});

	var baseother = $('<div />', {class:'party-hero-baseother'});

	var klass = $('<div />', {class:'party-hero-class'});
	var klassTitle = $('<div />', {class:'party-hero-title', text: app.local('Class')});
	var klassValue = $('<div />', {class:'party-hero-value', text: app.local(this.class)});
	var race = $('<div />', {class:'party-hero-race'});
	var raceTitle = $('<div />', {class:'party-hero-title', text: app.local('Race')});
	var raceValue = $('<div />', {class:'party-hero-value', text: app.local(this.race)});
	var level = $('<div />', {class:'party-hero-level'});
	var levelTitle = $('<div />', {class:'party-hero-title', text: app.local('Level')});
	var levelValue = $('<div />', {class:'party-hero-value', text: this.level});
	var aligment = $('<div />', {class:'party-hero-aligment'});
	var aligmentTitle = $('<div />', {class:'party-hero-title', text: app.local('Aligment')});
	var aligmentValue = $('<div />', {class:'party-hero-value', text: app.local(this.aligment)});
	var exp = $('<div />', {class:'party-hero-exp'});
	var expTitle = $('<div />', {class:'party-hero-title', text: app.local('Exp')});
	var expValue = $('<div />', {class:'party-hero-value', text: this.exp || 100});


	var abilities = $('<div />', {class:'party-hero-abilities'});

	var proficiencyBonusTable = this.createHTMLproficiencyTable();


	var abilitiesTable = this.createHTMLAbilityTable();
	this.createHTMLSkills();

	var battle = $('<div />', {class:'party-hero-battle'});






	var block3 = $('<div />', {class:'party-hero-battle'});
	
	var initiative = $('<div />', {class:'party-hero-initiative'});
	var initiativeTitle = $('<div />', {class:'party-hero-title', text: app.local('Initiative')});
	var initiativeValue = $('<div />', {class:'party-hero-value-large', text: this.initiative});

	var speed = $('<div />', {class:'party-hero-speed'});
	var speedTitle = $('<div />', {class:'party-hero-title', text: app.local('Speed')});
	var speedValue = $('<div />', {class:'party-hero-value-large', text: this.speed});


	this.$divStats
	.append(base
		.append(name
			.append(nameTitle)
			.append(nameValue)
		)
		.append(baseother
			.append(klass
				.append(klassTitle)
				.append(klassValue)
			)
			.append(race
				.append(raceTitle)
				.append(raceValue)
			)
			.append(level
				.append(levelTitle)
				.append(levelValue)
			)
			.append(aligment
				.append(aligmentTitle)
				.append(aligmentValue)
			)
			.append(exp
				.append(expTitle)
				.append(expValue)
			)
		)
	)
	.append(abilities
		.append(proficiencyBonusTable)
		.append(abilitiesTable)
	)
	.append(battle
		.append(this.createHTMLarmorClass())
		.append(this.createHTMLhealth())
	)
	.append(block3 
		.append(initiative
			.append(initiativeTitle)
			.append(initiativeValue)
		)
		.append(speed
			.append(speedTitle)
			.append(speedValue)
		)
	)
}

UI_Party_Hero.prototype.createHTMLAbilityTable = function() {
	var abilitiesTable = $('<table />', {class:'party-hero-abilities-table'}).attr('width','100%').attr('cellpadding','5px');
		this.$abilitiesTbody = $('<tbody />').attr('valign','top');
		abilitiesTable.append(this.$abilitiesTbody);
		var arr = [[
			'str', app.local('STR')
		], [
			'dex', app.local('DEX')
		], [
			'con', app.local('CON')
		], [
			'int', app.local('INT')
		], [
			'wis', app.local('WIS')
		], [
			'cha', app.local('CHA')
		], ]
		arr.forEach(function(o,i,a){
			this['$abilitiesTr'+o[0]] = $('<tr />')
			var $td1 = $('<td />');
			this['$skillsTd'+o[0]] = $('<td />', {class:'tdSkill'}).attr('width','100%');
			this[o[0]] = new UI_Party_Hero_Ability({
				data: {
					title: o[1],
					value: this.data[o[0]]
				},
				component: this
			})
			abilitiesTable
				.append(this['$abilitiesTr'+o[0]]
					.append($td1
						.append(this[o[0]].$div)
					)
					.append(this['$skillsTd'+o[0]])
				)
		},this)
	return abilitiesTable;
}

UI_Party_Hero.prototype.createHTMLSkills = function() {
	for (var i in UI_Party_Hero_Skill.prototype.initBase) {
		var skill = new UI_Party_Hero_Skill({id:i,val:this.data[i],component:this});
		this.skills.push(skill);
		this.skillsIndex[i] = skill;
		this['$skillsTd'+skill.ability].append(skill.$div);
	}
}


UI_Party_Hero.prototype.createHTMLproficiencyTable = function() {
	var proficiencyBonusTable = $('<table />', {class:'party-hero-proficiencyBonus-table'}).attr('width','90%').attr('cellpadding','0px').attr('cellspacing','0px');
	
	var tbTr = $('<tr />')
	
	var tbTd1 = $('<td />')
	var proficiencyBonusValue = $('<div />', {class:'party-hero-proficiencyBonus-value'});
	var proficiencyBonusValueWrapper = $('<div />', {class:'party-hero-proficiencyBonus-value-wrapper'});
	var proficiencyBonusValueSpan = $('<big />', {text:'+1'});
	
	var tbTd2 = $('<td />').attr('width','100%')
	var proficiencyBonusTitle = $('<div />', {class:'party-hero-proficiencyBonus-title'});
	var proficiencyBonusTitleWrapper = $('<div />', {class:'party-hero-proficiencyBonus-title-wrapper',text:app.local('Proficiency bonus')});

	
	var inTr = $('<tr />')
	
	var inTd1 = $('<td />')
	var inspirationValue = $('<div />', {class:'party-hero-proficiencyBonus-value'});
	var inspirationValueWrapper = $('<div />', {class:'party-hero-proficiencyBonus-value-wrapper'});
	var inspirationValueSpan = $('<big />').html('&#10003;');
	
	var inTd2 = $('<td />').attr('width','100%')
	var inspirationTitle = $('<div />', {class:'party-hero-proficiencyBonus-title'});
	var inspirationTitleWrapper = $('<div />', {class:'party-hero-proficiencyBonus-title-wrapper',text:app.local('Inspiration')});



	proficiencyBonusTable
	.append(tbTr
		.append(tbTd1
			.append(proficiencyBonusValue
				.append(proficiencyBonusValueWrapper
					.append(proficiencyBonusValueSpan)
				)
			)
		)
		.append(tbTd2
			.append(proficiencyBonusTitle
				.append(proficiencyBonusTitleWrapper)
			)
		)
	)
	.append(inTr
		.append(inTd1
			.append(inspirationValue
				.append(inspirationValueWrapper
					.append(inspirationValueSpan)
				)
			)
		)
		.append(inTd2
			.append(inspirationTitle
				.append(inspirationTitleWrapper)
			)
		)
	)

	return proficiencyBonusTable;
}

UI_Party_Hero.prototype.createHTMLarmorClass= function() {
	var table = $('<table/>', {class:'party-hero-abilities-table'}).attr({width:'90%',cellpadding:0,cellspacing:0})
	var tbody = $('<tbody />').attr({valign:'top'});
	var tr = $('<tr/>');
	var td1 = $('<td/>');
	var td2 = $('<td/>');

	var ac = $('<div />', {class:'party-hero-ac'})
	var acValue = $('<div />', {class:'party-hero-acValue',text:this.ac})
	var acTitle = $('<div />', {class:'party-hero-acTitle',text:app.local('Armor class')})

	var acPart1 = $('<div />', {class:'party-hero-skill'})
	var acPart1Value = $('<div />', {class:'party-hero-skill-value',text:app.getModSimbol(8)})
	var acPart1Title = $('<div />', {class:'party-hero-skill-title',text:app.local('Dexterity modifier')})

	var acPart2 = $('<div />', {class:'party-hero-skill'})
	var acPart2Value = $('<div />', {class:'party-hero-skill-value',text:app.getModSimbol(4)})
	var acPart2Title = $('<div />', {class:'party-hero-skill-title',text:app.local('Armor')})

	var acPart3 = $('<div />', {class:'party-hero-skill'})
	var acPart3Value = $('<div />', {class:'party-hero-skill-value',text:app.getModSimbol(6)})
	var acPart3Title = $('<div />', {class:'party-hero-skill-title',text:app.local('Shield')})

	var acPart4 = $('<div />', {class:'party-hero-skill'})
	var acPart4Value = $('<div />', {class:'party-hero-skill-value',text:app.getModSimbol(3)})
	var acPart4Title = $('<div />', {class:'party-hero-skill-title',text:app.local('Misc')})

	return table
		.append(tbody
			.append(tr
				.append(td1
					.append(ac
						.append(acTitle)
						.append(acValue)
					)
				)
				.append(td2
					.append(acPart1
						.append(acPart1Value)
						.append(acPart1Title)
					)
					.append(acPart2
						.append(acPart2Value)
						.append(acPart2Title)
					)
					.append(acPart3
						.append(acPart3Value)
						.append(acPart3Title)
					)
					.append(acPart4
						.append(acPart4Value)
						.append(acPart4Title)
					)
				)
			)
		)
}

UI_Party_Hero.prototype.createHTMLhealth= function() {
	var block = $('<div />', {class:'party-hero-hpblock'});
	var hp= $('<div />', {class:'party-hero-hp'});
	var hpMax= $('<div />', {class:'party-hero-hpMax'});
	var hpMaxTitle= $('<div />', {class:'party-hero-hpMaxTitle', text:app.local('Hit Point Maximum')});
	var hpMaxValue= $('<div />', {class:'party-hero-hpMaxValue', text:53});
	var hpCur= $('<div />', {class:'party-hero-hpCur'});
	var hpCurTitle= $('<div />', {class:'party-hero-hpCurTitle', text:app.local('Current Hit Points')});
	var hpCurValue= $('<div />', {class:'party-hero-hpCurValue', text:38});


	// var hitDiceWrap= $('<div />', {class:'party-hero-hp-left'});
	// var total= $('<div />', {class:'party-hero-hpMax'});
	// var totalTitle= $('<div />', {class:'party-hero-hpMaxTitle', text:app.local('Total')});
	// var totalValue= $('<div />', {class:'party-hero-hpMaxValue', text:53});

	// var hitDice= $('<div />', {class:'party-hero-hitDice'});
	// var hitDiceTitle= $('<div />', {class:'party-hero-hitDiceTitle', text:app.local('Hit dice')});
	// var hitDiceValue= $('<div />', {class:'party-hero-hitDiceValue', text:app.local('d')+20});

	// var death = $('<div />', {class:'party-hero-hp-right'});

	return block
		.append(hp
			.append(hpMax
				.append(hpMaxTitle)
				.append(hpMaxValue)
			)
			.append(hpCur
				.append(hpCurTitle)
				.append(hpCurValue)
			)
		)
		// .append(hitDiceWrap
		// 	.append(total
		// 		.append(totalTitle)
		// 		.append(totalValue)
		// 	)
		// 	.append(hitDice
		// 		.append(hitDiceTitle)
		// 		.append(hitDiceValue)
		// 	)
		// )
		// .append(death

		// );
}






UI_Party_Hero.prototype.updateHTML = function(o) {
	if (!o || o.displayed) {
		if (this.displayed) {
			this.$divInList.addClass('selected');
			this.$l_header.addClass('selected');
			this.$stats.append(this.$divStats);
		} else { 
			this.$divInList.removeClass('selected');
			this.$l_header.removeClass('selected');
			this.$divStats.detach();
		}
	}
}

UI_Party_Hero.prototype.callEvent = function(eventName, arg) {
	if (this.events.hasOwnProperty(eventName)) {
		for (var i = this.events[eventName].length - 1; i >= 0; i--) {
			this.events[eventName][i](arg)
		};
	}
	else {
		console.log('Нет события ' + eventName)
	}
}

UI_Party_Hero.prototype.signUpForAnEvent = function(eventName, func) {
	if (!this.events.hasOwnProperty(eventName)) {
		this.events[eventName] = [];
	}
	this.events[eventName].push(func);
}

UI_Party_Hero.prototype.bindEvents = function() {
	this.module.signUpForAnEvent('selectHero', function(self){
		return function(heroId) {
			var prev = self.displayed;
			self.displayed = self.id == heroId ? true : false;
			if (prev != self.displayed) {
				self.updateHTML();
			}
		}
	}(this))
}

