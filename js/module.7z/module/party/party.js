var UI_Party = function(o) {
	if (!o.hasOwnProperty('div')) {
		throw new Error('Нет свойства div');
	} else {
		if (typeof o.div == 'string') {
			this.$div = $(o.div)
		} else {
			this.$div = o.div;
		}
	}
	if (!o.hasOwnProperty('app')) {
		throw new Error('Нет свойства app');
	} else {
		this.app = o.app;
	}
	this.party = [];
	this.partyIndex = {};
	this.events = {};
	this.id = o.id
	this.displayed = false;
	this.init();
}

UI_Party.prototype.createHtml = function() {

	this.$heroesList = $('<div />', {class: 'firstColumn'});
	this.$div.append(this.$heroesList);
	var header = $('<h5 />', {
		class: 'block-header',
		text: app.local('Party')
	})
	this.$heroesList.append(header)


	this.$buttons = $('<div />',{class:'block-padding'})
	this.$heroesList.append(this.$buttons);
	

	this.$buttonNewhero = $('<span />', {
		class: 'inline-button monster-subHeaderButton',
		text: app.local('New'),
		click: function(self) {
			return function() {
				self.app.callEvent('heroNew');
			}
		}(this)
	});
	this.$buttons.append(this.$buttonNewhero);



	this.$list = $('<div/>', {
		class: 'block-list'
	}).css({top:'70px'})
	this.$heroesList.append(this.$list)


	this.$heroeStats = $('<div />', {class: 'firstColumnAfter'});
	this.$div.append(this.$heroeStats);

	// this.$monsters = $('<div />', {class: 'secondColumn'});
	// this.$div.append(this.$monsters);

}
UI_Party.prototype.updateHTML = function(o) {
	if (!o || o.displayed) {
		if (this.displayed) {
			this.$div.removeClass('nondisplay');
		} else {
			this.$div.addClass('nondisplay');
		}
	}

};
UI_Party.prototype.init = function(o) {
	this.createHtml();
	this.genParty();
	this.bindEvents();
};

UI_Party.prototype.genParty = function(arg) {
	var partyData = this.getParrtyData();
	var len = partyData.length;
	for (var i = 0; i < len; i++) {
		var hero = new UI_Party_Hero({data:partyData[i], statdiv: this.$heroeStats, module:this});
		this.party.push(hero);
		this.partyIndex[partyData[i].name] = hero;
		this.$list.append(hero.$divInList);
	}
};



UI_Party.prototype.signUpForAnEvent = function(eventName, func) {
	if (!this.events.hasOwnProperty(eventName)) {
		this.events[eventName] = [];
	}
	this.events[eventName].push(func);
}

UI_Party.prototype.callEvent = function(eventName, arg) {
	if (this.events.hasOwnProperty(eventName)) {
		for (var i = this.events[eventName].length - 1; i >= 0; i--) {
			this.events[eventName][i](arg)
		};
	}
	else {
		console.log('Нет события ' + eventName)
	}
}


UI_Party.prototype.bindEvents = function() {

	this.app.signUpForAnEvent('selectModule', function(self){
		return function(moduleId) {
			var prev = self.displayed;
			self.displayed = self.id == moduleId ? true : false;
			if (prev != self.displayed) {
				self.updateHTML();
			}
		}
	}(this))



}

UI_Party.prototype.getHeroStateForMonsterView = function(name) {
	return this.partyIndex[name].data;
}


UI_Party.prototype.getParrtyData = function(o) {
	return [
		{
			id : 'Барик Теоденович',
			name : 'Барик Теоденович',
			type : '',
			race : 'Человек', // такое свойство есть только  у героев
			class : 'Воин', // такое свойство есть только  у героев
			level : '1', // такое свойство есть только  у героев
			aligment : 'Lawful neutral',
			ac : 17,
			acType : '',
			hp : 12,
			hpFormula : '8+4',
			speed : 30,
			str : 16,
			dex : 9,
			con : 15,
			int : 11,
			wis : 13,
			cha : 14,
			saveThrows : '',
			skills : '',
				Acrobatics : -1,
				'Animal handing' : 3,
				Arcana : 0,
				Atletics : 4,
				Deception : 1,
				History : 0,
				Insight : 3,
				Intimidate : 3,
				Investigation : 0,
				Medicine : 5,
				Nature : 0,
				Perception : 3,
				Perfomance : 1,
				Persuasion : 1,
				Religion : 2,
				'Sleight of hand' : -1,
				Stealtg : -1,
				Survival : 3,

				initiative : 3,
			damageResistances : '',
			damageImmunities : '',
			conditionImmunities : '',
			senses : '',
			languages : '',
			challenge : '',
			xp : '',
			description : '',
			actions : '',
			legendaryActions : '',
			additionalSetting : '',
		},{
			id : 'Мордур',
			name : 'Мордур',
			type : '',
			race : 'Дроу', // такое свойство есть только  у героев
			class : 'Вор', // такое свойство есть только  у героев
			level : '1', // такое свойство есть только  у героев
			aligment : 'Chatic Good',
			ac : 15,
			acType : '',
			hp : 8,
			hpFormula : '8+0',
			speed : 25,
			str : 8,
			dex : 18,
			con : 10,
			int : 14,
			wis : 14,
			cha : 13,
			saveThrows : '',
			skills : '',
				Acrobatics : -1,
				'Animal handing' : 3,
				Arcana : 0,
				Atletics : 4,
				Deception : 1,
				History : 0,
				Insight : 3,
				Intimidate : 3,
				Investigation : 0,
				Medicine : 5,
				Nature : 0,
				Perception : 3,
				Perfomance : 1,
				Persuasion : 1,
				Religion : 2,
				'Sleight of hand' : -1,
				Stealtg : -1,
				Survival : 3,

				initiative : 3,
			damageResistances : '',
			damageImmunities : '',
			conditionImmunities : '',
			senses : '',
			languages : '',
			challenge : '',
			xp : '',
			description : '',
			actions : '',
			legendaryActions : '',
			additionalSetting : '',
		},{
			id : 'Нумерик',
			name : 'Нумерик',
			type : '',
			race : 'High elf', // такое свойство есть только  у героев
			class : 'Волшебник', // такое свойство есть только  у героев
			level : '1', // такое свойство есть только  у героев
			aligment : 'Chatic good',
			ac : 12,
			acType : '',
			hp : 8,
			hpFormula : '6+2',
			speed : 30,
			str : 10,
			dex : 15,
			con : 14,
			int : 16,
			wis : 12,
			cha : 8,
			saveThrows : '',
			skills : '',
				Acrobatics : -1,
				'Animal handing' : 3,
				Arcana : 0,
				Atletics : 4,
				Deception : 1,
				History : 0,
				Insight : 3,
				Intimidate : 3,
				Investigation : 0,
				Medicine : 5,
				Nature : 0,
				Perception : 3,
				Perfomance : 1,
				Persuasion : 1,
				Religion : 2,
				'Sleight of hand' : -1,
				Stealtg : -1,
				Survival : 3,

				initiative : 3,
			damageResistances : '',
			damageImmunities : '',
			conditionImmunities : '',
			senses : '',
			languages : '',
			challenge : '',
			xp : '',
			description : '',
			actions : '',
			legendaryActions : '',
			additionalSetting : '',
		}	]
};