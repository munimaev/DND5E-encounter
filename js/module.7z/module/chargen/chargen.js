var UI_Chargen = function(o) {
	this.uiChangenMain = new UI_Chargen_main({div:'#gm', module:this});
	this.uiChargenAbilties = new UI_Chargen_abilities({div:'#ga', module:this});
	this.uiChargenSteps = new UI_Chargen_steps({div:'#gs', module:this});
	this.uiChargenRace = new UI_Chargen_race({div:'#gr', module:this});
	this.uiChargenClass = new UI_Chargen_class({div:'#gc', module:this});

	this.uiChargenSteps.init();
	this.uiChangenMain.init();
	this.uiChargenRace.init();
	this.uiChargenClass.init();
	this.uiChargenAbilties.init();

	this.uiChangenMain.setRace('Elf');

}

UI_Chargen.prototype.callEvent = function(name, args) {
	if (this.events.hasOwnProperty(name)) {
		this.events[name].forEach(function(v,i,a){v(args)})
	}
};
UI_Chargen.prototype.events = {};
UI_Chargen.prototype.events.changeRace = [];
UI_Chargen.prototype.events.changeSubrace = [];
UI_Chargen.prototype.events.changeClass = [];
UI_Chargen.prototype.events.changeStep = [];



UI_Chargen.prototype.getCurrentRace = function() {
	return this.uiChargenRace.race;
}
UI_Chargen.prototype.getCurrentSubrace = function() {
	var result = this.uiChargenRace.subrace
	return result;	
}