var UI_Encounter_data = function() {
	this.base = {};
	this.list = [];
}

UI_Encounter_data.prototype.init = function() {
}

