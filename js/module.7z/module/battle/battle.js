var UI_Battle = function(o) {


	this.currentModule = null;
	this.previousModule = null;

	this.events = {};
	this.bindEvents();




	this.uiHeader = new UI_Header({div:'#h', app:this, id:'header'});
	this.uiEncounters = new UI_Encounter({div:'#e', app:this, id:'encounter'});
	this.uiBattle = new UI_Battle_Encounters({div:'#b', app:this, id:'battle'});
	this.uiParty = new UI_Party({div:'#p', app:this, id:'party'});

	this.modulesIndex = {
		uiHeader : this.uiHeader,
		uiEncounters : this.uiEncounters,
		uiBattle : this.uiBattle,
		uiParty : this.uiParty,
	}
	this.modules = [
		this.uiHeader,
		this.uiEncounters,
		this.uiBattle,
		this.uiParty,
	]


	this.uiHeader.init();
	this.uiBattle.init();
	this.uiEncounters.init();

	this.callEvent('selectModule','party')
	this.uiParty.callEvent('selectHero','Барик Теоденович')

}

UI_Battle.prototype.signUpForAnEvent = function(eventName, func) {
	if (!this.events.hasOwnProperty(eventName)) {
		this.events[eventName] = [];
	}
	this.events[eventName].push(func);
}

UI_Battle.prototype.callEvent = function(eventName, arg) {
	if (this.events.hasOwnProperty(eventName)) {
		for (var i = this.events[eventName].length - 1; i >= 0; i--) {
			this.events[eventName][i](arg)
		};
	}
	else {
		console.log('Нет события ' + eventName)
	}
}

UI_Battle.prototype.getHeroStateForMonsterView = function(name) {
	return this.uiParty.partyIndex[name].data;
}

UI_Battle.prototype.bindEvents = function() {

	this.signUpForAnEvent('selectModule', function(self){
		return function(moduleId) {
			self.previousModule = self.currentModule;
			self.currentModule = moduleId;
		}
	}(this))

	this.signUpForAnEvent('selectModulePrev', function(self){
		return function() {
			self.callEvent('selectModule',self.previousModule)
		}
	}(this))

	this.signUpForAnEvent('encounterEdit', function(self){
		return function(encounterId) {
			self.callEvent('selectModule','encounter')
		}
	}(this))

	this.signUpForAnEvent('encounterNew', function(self){
		return function() {
			self.callEvent('selectModule','encounter')
		}
	}(this))


}

